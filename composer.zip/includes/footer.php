<footer>
        <p> Josh Rickards &copy;</p>
</footer>